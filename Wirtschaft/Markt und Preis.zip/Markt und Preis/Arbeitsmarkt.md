Arbeitgeber und nehmer
[[Lehrstellenmarkt]]
