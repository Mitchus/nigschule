# Technische Dokumentation – Bestellverwaltung

**Fach:** ZQ
**Thema:** Prompting – KI als Entwicklungsassistent im Berufsalltag
**Datum:** 02.03.2026

---

## Phase 1 – Programmbeschreibung

Die Bestellverwaltung ist eine webbasierte Vollstack-Anwendung zur Erfassung, Bearbeitung und Verwaltung von Bestellungen. Der Zugriff ist durch Keycloak abgesichert – nur angemeldete Benutzer können die Anwendung nutzen.

| Komponente | Technologie | Port |
| --- | --- | --- |
| Backend | Spring Boot 3 (Java 17) | 8081 |
| Frontend | React 18 + Vite | 5173 |
| Authentifizierung | Keycloak 24 (Docker) | 8080 |
| Datenbank | H2 (In-Memory) | – |

---

## Phase 2 – Debugging

### Fehlerhafter Code (Ausgangslage)

```java
@PostMapping
public ResponseEntity<Order> create(@RequestBody Order order) {
    String menge = order.getMenge();        // Fehler 1
    String preis = order.getEinzelpreis(); // Fehler 2
    int gesamtpreis = menge * preis;       // Fehler 3
    order.setGesamtpreis(gesamtpreis);
    return ResponseEntity.ok(repository.save(order));
}
```

### 1. Analyse des Problems

Der Code enthält drei zusammenhängende Fehler:

| Nr | Zeile | Problem |
| --- | --- | --- |
| 1 | `String menge = order.getMenge()` | `getMenge()` gibt `int` zurück – Zuweisung an `String` falsch |
| 2 | `String preis = order.getEinzelpreis()` | `getEinzelpreis()` gibt `double` zurück – falscher Typ |
| 3 | `int gesamtpreis = menge * preis` | Strings können nicht multipliziert werden – Compilerfehler |

### 2. Warum tritt der Fehler auf?

Java ist eine **streng typisierte** Sprache. Jede Variable hat einen festen Datentyp, der zur Compilezeit geprüft wird. `String` und numerische Typen sind grundverschieden:

| Typ | Art | Beispiel | Rechenoperationen |
| --- | --- | --- | --- |
| `String` | Zeichenkette | `"42"` | Nicht möglich (`*` nicht definiert) |
| `int` | Ganzzahl | `42` | Voll möglich |
| `double` | Dezimalzahl | `9.99` | Voll möglich |

Der Operator `*` funktioniert nur mit numerischen Typen. Auf `String`-Variablen angewendet wirft der Compiler: `error: bad operand types for binary operator '*'`

### 3. Unterschied String vs. Integer

- **String** speichert Text als Zeichenfolge. Die Zahl `"5"` ist für Java nur ein Zeichen – kein Zahlenwert. `"5" * "3"` ist nicht definiert.
- **int / Integer** speichert eine ganze Zahl als Binärwert. `5 * 3 = 15` funktioniert direkt.
- Umwandlung wäre möglich mit `Integer.parseInt("5")`, ist hier aber unnötig – die Getter liefern bereits die richtigen numerischen Typen.

### 4. Korrigierter Code

```java
@PostMapping
public ResponseEntity<Order> create(@Valid @RequestBody Order order) {
    int    menge        = order.getMenge();        // int, kein String
    double preis        = order.getEinzelpreis(); // double, kein String
    double gesamtpreis  = menge * preis;
    order.setGesamtpreis(gesamtpreis);
    return ResponseEntity.ok(repository.save(order));
}
```

**Eigene Verbesserung:** Die Berechnung wurde aus dem Controller in `@PrePersist`/`@PreUpdate` der Entity verschoben, sodass der Gesamtpreis bei jeder Speicheroperation automatisch korrekt berechnet wird – korrekte Schichtentrennung.

---

## Phase 3 – Technische Dokumentation

### Funktionsweise

**Authentifizierung (Keycloak)**

1. Browser öffnet `localhost:5173`
2. Keycloak-JS erkennt fehlenden Token → Weiterleitung zur Loginseite
3. Nach Login wird ein JWT-Token ausgestellt
4. Token wird bei jedem API-Request im `Authorization: Bearer`-Header mitgesendet
5. Backend prüft Token als OAuth2 Resource Server gegen Keycloak
6. Läuft Token ab, erneuert `keycloak.updateToken(30)` ihn automatisch

**Backend (Spring Boot)**

- REST-API unter `/api/orders`
- Eingabevalidierung via `jakarta.validation` (`@NotBlank`, `@DecimalMin`, `@Min`)
- Gesamtpreis wird automatisch in der Entity berechnet (`@PrePersist`/`@PreUpdate`)
- Daten in H2 In-Memory-Datenbank (gehen bei Neustart verloren)

**Frontend (React)**

- Alle Bestellungen in einer Tabelle mit dunklem Design
- Neue Bestellungen über ein Formular erfassen
- Inline-Bearbeitung: Doppelklick auf Produktname, Preis oder Menge → direkt editierbar
- Enter = Speichern, Escape = Abbrechen, ungültige Werte werden verworfen
- Gesamtsumme aller Bestellungen wird live am Seitenende angezeigt

### Verwendete Variablen / Datenfelder

**Order – Backend-Entität (`Order.java`)**

| Feld | Typ | Beschreibung | Validierung |
| --- | --- | --- | --- |
| `id` | `Long` | Automatisch generierter Primärschlüssel | – |
| `produktname` | `String` | Name des bestellten Produkts | `@NotBlank` |
| `einzelpreis` | `double` | Preis pro Einheit in Euro | `@DecimalMin("0.01")` |
| `menge` | `int` | Bestellte Stückzahl | `@Min(1)` |
| `gesamtpreis` | `double` | Automatisch: `einzelpreis × menge` | via `@PrePersist` |

**Frontend – App.jsx**

| Variable | Typ | Beschreibung |
| --- | --- | --- |
| `orders` | `Array` | Liste aller Bestellungen vom Backend |
| `summe` | `number` | Gesamtsumme aller Bestellungen in Euro |

**Frontend – OrderForm.jsx**

| Variable | Typ | Beschreibung |
| --- | --- | --- |
| `form` | `Object` | Eingabefelder: `produktname`, `einzelpreis`, `menge` |
| `fehler` | `String` | Fehlermeldung bei ungültiger Eingabe |
| `loading` | `boolean` | Sperrt Button während des API-Requests |
| `focused` | `String` | Aktuell fokussiertes Feld (visuelles Feedback) |

**Frontend – OrderList.jsx (EditableCell)**

| Variable | Typ | Beschreibung |
| --- | --- | --- |
| `editing` | `boolean` | Gibt an ob das Feld gerade bearbeitet wird |
| `draft` | `String` | Temporärer Wert während der Eingabe |

### Programmablauf

```
Browser öffnet http://localhost:5173
        │
        ▼
Keycloak: Kein Token → Loginseite (testuser / password)
        │
        ▼
JWT-Token ausgestellt → React App lädt
        │
        ▼
GET /api/orders       → Tabelle befüllen
GET /api/orders/summe → Gesamtsumme anzeigen
        │
   ┌────┼──────────────────┐
   ▼    ▼                  ▼
  NEU  BEARBEITEN        LÖSCHEN
   │    │                  │
   │  Doppelklick       DELETE /api/orders/{id}
   │  Enter → PUT          │
   │  Esc   → Revert    204 → Liste neu laden
   ▼    ▼
POST/PUT /api/orders[/{id}]
        │
        ▼
Validierung (Backend)
   ├─ Fehler → HTTP 400 → Fehlermeldung im Frontend
   └─ OK → @PrePersist berechnet Gesamtpreis
          → H2 speichern → HTTP 200
          → Liste + Summe neu laden
```

### REST-API Übersicht

| Methode | Endpunkt | Beschreibung | Auth |
| --- | --- | --- | --- |
| GET | `/api/orders` | Alle Bestellungen abrufen | JWT |
| POST | `/api/orders` | Neue Bestellung erstellen | JWT |
| PUT | `/api/orders/{id}` | Bestellung aktualisieren | JWT |
| DELETE | `/api/orders/{id}` | Bestellung löschen | JWT |
| GET | `/api/orders/summe` | Gesamtsumme aller Bestellungen | JWT |

Beispiel PUT-Request Body: `{ "produktname": "Laptop", "einzelpreis": 899.99, "menge": 2 }`
Beispiel Response: `{ "id": 1, "produktname": "Laptop", "einzelpreis": 899.99, "menge": 2, "gesamtpreis": 1799.98 }`

### Projektstruktur

```
bestellverwaltung/
├── docker-compose.yml
├── keycloak/realm-export.json
├── backend/
│   ├── pom.xml
│   └── src/main/java/.../
│       ├── config/SecurityConfig.java      – JWT + CORS
│       ├── controller/OrderController.java – REST (GET/POST/PUT/DELETE)
│       ├── service/OrderService.java       – Geschäftslogik
│       ├── repository/OrderRepository.java – JPA + Summen-Query
│       └── model/Order.java               – Entität + @PrePersist
└── frontend/src/
    ├── keycloak.js       – Adapter
    ├── main.jsx          – Login-Required
    ├── App.jsx           – Interceptor + State
    └── components/
        ├── OrderForm.jsx – Formular
        └── OrderList.jsx – Tabelle + Inline-Editing
```

### Hinweise zur Erweiterung

| Erweiterung | Umsetzung |
| --- | --- |
| Persistente Datenbank | H2 → PostgreSQL, `spring.datasource.*` in `application.yml` anpassen |
| Rollen-basierter Zugriff | `@PreAuthorize("hasRole('ADMIN')")` + Rolle in Keycloak vergeben |
| Produktkatalog | Neue Entität `Product`, Fremdschlüssel in `Order` |
| Export (CSV/PDF) | GET `/api/orders/export`, Apache POI oder iText |
| Bestellstatus | Enum `Status { OFFEN, BEARBEITET, VERSANDT }` in `Order` |

### Reflexion – KI-Dokumentation

| Bereich | Problem (KI-Ausgabe) | Nachbesserung |
| --- | --- | --- |
| Schichtentrennung | Preisberechnung im Controller | In `@PrePersist` der Entity verschoben |
| Validierung | `@Min` für Dezimalpreise | `@DecimalMin("0.01")` ergänzt |
| CORS | `@CrossOrigin` am Controller | Zentral in `SecurityConfig` |
| Token-Refresh | Nicht implementiert | `keycloak.updateToken(30)` im Interceptor |
| H2-Konsole | Durch Security blockiert | `frameOptions.disable()` ergänzt |
| PUT-Endpunkt | Initial nicht vorhanden | Manuell nachgebaut |
| Test-Imports | Fehlende `static`-Imports | `import static org.mockito.Mockito.*` |

---

## Phase 4 – Testfälle

Die Testfälle wurden von der KI vorgeschlagen und anschließend fachlich geprüft, ergänzt und korrigiert.

### Controller-Tests – HTTP-Ebene (12 Tests)

| Nr | Testfall | Eingabe | Erwartetes Ergebnis | Tatsächliches Ergebnis |
| --- | --- | --- | --- | --- |
| 1 | Normale Werte | `produktname="Laptop"`, `preis=999.99`, `menge=2` | HTTP 200, `gesamtpreis=1999.98` | HTTP 200 ✓ |
| 2 | Menge = 0 | `produktname="Stift"`, `preis=1.50`, `menge=0` | HTTP 400 Bad Request | HTTP 400 ✓ |
| 3 | Menge negativ | `produktname="Stift"`, `preis=1.50`, `menge=-5` | HTTP 400 Bad Request | HTTP 400 ✓ |
| 4 | Preis = 0.00 | `produktname="Stift"`, `preis=0.00`, `menge=1` | HTTP 400 Bad Request | HTTP 400 ✓ |
| 5 | Preis negativ | `produktname="Stift"`, `preis=-9.99`, `menge=1` | HTTP 400 Bad Request | HTTP 400 ✓ |
| 6 | Name leer | `produktname=""`, `preis=5.00`, `menge=1` | HTTP 400 Bad Request | HTTP 400 ✓ |
| 7 | Name fehlt (null) | Kein `produktname`-Feld im JSON | HTTP 400 Bad Request | HTTP 400 ✓ |
| 8 | Sehr große Zahlen | `preis=9999999.99`, `menge=99` | HTTP 200, korrekte Summe | HTTP 200 ✓ |
| 9 | Falscher Typ | `einzelpreis="abc"` (String statt Zahl) | HTTP 400 Bad Request | HTTP 400 ✓ |
| 10 | Bestellung löschen | DELETE `/api/orders/1` | HTTP 204 No Content | HTTP 204 ✓ |
| 11 | Gesamtsumme | GET `/api/orders/summe` | HTTP 200 + `gesamtsumme: 149.97` | HTTP 200 ✓ |

### Unit-Tests – Gesamtpreis-Berechnung (4 Tests)

| Nr | Testfall | Einzelpreis | Menge | Erwarteter Gesamtpreis | Tatsächlich |
| --- | --- | --- | --- | --- | --- |
| 1 | Normale Werte | 9,99 € | 3 | 29,97 € | 29,97 € ✓ |
| 2 | Menge = 1 | 49,99 € | 1 | 49,99 € | 49,99 € ✓ |
| 3 | Sehr großer Preis | 99.999,99 € | 1.000 | 99.999.990,00 € | korrekt ✓ |
| 4 | Sehr große Menge | 0,01 € | 1.000.000 | 10.000,00 € | korrekt ✓ |

**Kritische Prüfung der KI-Testvorschläge:**
- KI schlug `menge=0` vor, vergaß aber den `null`-Fall → manuell ergänzt
- KI testete keinen falschen Datentyp (`"abc"` als Preis) → manuell ergänzt
- Grenzwerttests für sehr große Zahlen fehlten → manuell ergänzt

---

## Abschlussreflexion

**1. Wo hat die KI gut unterstützt?**

Die KI hat die grundlegende Projektstruktur korrekt aufgebaut: Schichtentrennung (Controller → Service → Repository), Maven-Konfiguration, Keycloak-JWT-Integration und React-Komponenten waren sofort lauffähig. Für Boilerplate-Code wie Entity, Repository-Interface und Axios-Interceptor spart man erheblich Zeit. Auch die Testfälle wurden strukturiert und mit sinnvollen Grenzwerten generiert.

**2. Wo war sie fehlerhaft oder ungenau?**

- Gesamtpreis wurde im Controller statt in der Entity berechnet (falsche Schicht)
- `@Min` für Dezimalpreise statt `@DecimalMin("0.01")`
- CORS direkt am Controller statt zentral in der Security-Konfiguration
- Kein automatischer JWT-Token-Refresh – im Produktiveinsatz ein kritischer Bug
- H2-Konsole war durch Spring Security blockiert und nicht erreichbar
- Fehlende statische Imports in den Tests – Code kompilierte nicht
- PUT-Endpunkt wurde initial nicht generiert

**3. Würdet ihr KI-Code direkt in ein Kundenprojekt übernehmen?**

Nein – nicht ohne gründliche Code-Review. KI-Code ist ein guter erster Entwurf, enthält aber regelmäßig subtile Fehler in Sicherheit, Validierung und Architektur. Sicherheitslücken, falsche Abstraktionsebenen und fehlendes Error-Handling können zu Produktionsausfällen oder Datenverlust führen. Jede Zeile muss geprüft werden.

**4. Wer trägt die Verantwortung für Fehler?**

Der Entwickler, der den Code übernimmt. Die KI ist ein Werkzeug – sie kennt nicht den Kontext, die Sicherheitsanforderungen oder die Konsequenzen von Fehlern. Wer Code deployt, trägt die vollständige Verantwortung, unabhängig davon ob er selbst oder eine KI ihn geschrieben hat.

**5. Was habt ihr über KI im Entwicklungsprozess gelernt?**

KI ist am nützlichsten als Beschleuniger für bekannte Muster – Boilerplate, Konfiguration, Teststruktur. Sie ersetzt kein technisches Verständnis: Wer die Grundlagen nicht kennt, erkennt auch die Fehler nicht. Der sinnvollste Einsatz: KI generiert den Rahmen, der Entwickler prüft, korrigiert und entscheidet – wie bei einem Junior-Entwickler, dem man Aufgaben gibt, dessen Ergebnis man aber nicht blind übernimmt.
