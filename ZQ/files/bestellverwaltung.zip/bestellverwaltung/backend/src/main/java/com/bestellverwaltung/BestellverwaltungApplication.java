package com.bestellverwaltung;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BestellverwaltungApplication {
    public static void main(String[] args) {
        SpringApplication.run(BestellverwaltungApplication.class, args);
    }
}
