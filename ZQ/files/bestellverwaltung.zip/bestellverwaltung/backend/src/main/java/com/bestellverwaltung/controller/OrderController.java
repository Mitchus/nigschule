package com.bestellverwaltung.controller;

import com.bestellverwaltung.model.Order;
import com.bestellverwaltung.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService service;

    public OrderController(OrderService service) {
        this.service = service;
    }

    @GetMapping
    public List<Order> getAll() {
        return service.alleBestellungen();
    }

    @PostMapping
    public ResponseEntity<Order> create(@Valid @RequestBody Order order) {
        return ResponseEntity.ok(service.bestellungHinzufuegen(order));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Order> update(@PathVariable Long id, @Valid @RequestBody Order order) {
        return ResponseEntity.ok(service.bestellungAktualisieren(id, order));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.bestellungLoeschen(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/summe")
    public Map<String, Double> summe() {
        return Map.of("gesamtsumme", service.gesamtsumme());
    }
}
