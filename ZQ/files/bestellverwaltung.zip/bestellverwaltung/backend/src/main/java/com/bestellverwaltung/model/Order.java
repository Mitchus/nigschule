package com.bestellverwaltung.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String produktname;

    @DecimalMin("0.01")
    private double einzelpreis;

    @Min(1)
    private int menge;

    // Gesamtpreis wird automatisch berechnet, nicht vom Client gesetzt
    private double gesamtpreis;

    @PrePersist
    @PreUpdate
    private void berechneGesamtpreis() {
        this.gesamtpreis = this.einzelpreis * this.menge;
    }

    // --- Getter & Setter ---

    public Long getId() { return id; }

    public String getProduktname() { return produktname; }
    public void setProduktname(String produktname) { this.produktname = produktname; }

    public double getEinzelpreis() { return einzelpreis; }
    public void setEinzelpreis(double einzelpreis) { this.einzelpreis = einzelpreis; }

    public int getMenge() { return menge; }
    public void setMenge(int menge) { this.menge = menge; }

    public double getGesamtpreis() { return gesamtpreis; }
}
