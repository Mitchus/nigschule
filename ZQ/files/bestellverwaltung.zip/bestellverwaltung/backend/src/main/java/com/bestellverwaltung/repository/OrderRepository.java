package com.bestellverwaltung.repository;

import com.bestellverwaltung.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface OrderRepository extends JpaRepository<Order, Long> {

    @Query("SELECT COALESCE(SUM(o.gesamtpreis), 0) FROM Order o")
    double summeAllerBestellungen();
}
