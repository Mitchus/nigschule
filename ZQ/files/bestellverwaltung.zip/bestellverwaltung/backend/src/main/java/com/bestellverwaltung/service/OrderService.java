package com.bestellverwaltung.service;

import com.bestellverwaltung.model.Order;
import com.bestellverwaltung.repository.OrderRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {

    private final OrderRepository repository;

    public OrderService(OrderRepository repository) {
        this.repository = repository;
    }

    public List<Order> alleBestellungen() {
        return repository.findAll();
    }

    public Order bestellungHinzufuegen(Order order) {
        return repository.save(order);
    }

    public Order bestellungAktualisieren(Long id, Order aktualisiert) {
        Order existing = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Bestellung nicht gefunden: " + id));
        existing.setProduktname(aktualisiert.getProduktname());
        existing.setEinzelpreis(aktualisiert.getEinzelpreis());
        existing.setMenge(aktualisiert.getMenge());
        return repository.save(existing);
    }

    public void bestellungLoeschen(Long id) {
        repository.deleteById(id);
    }

    public double gesamtsumme() {
        return repository.summeAllerBestellungen();
    }
}
