package com.bestellverwaltung.controller;

import com.bestellverwaltung.model.Order;
import com.bestellverwaltung.service.OrderService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integrationstests fuer den OrderController mit MockMvc.
 * Security wird mit @WithMockUser umgangen – kein echter Keycloak noetig.
 *
 * Testfall-Tabelle (Eingabe → Erwartetes Ergebnis → Tatsaechliches Ergebnis):
 *
 * ┌─────┬────────────────────────────────────────┬────────────────┬────────────────┐
 * │ Nr. │ Eingabe                                │ HTTP erwartet  │ HTTP erhalten  │
 * ├─────┼────────────────────────────────────────┼────────────────┼────────────────┤
 * │ C01 │ GET /api/orders (normal)               │ 200 + Liste    │ 200 + Liste    │
 * │ C02 │ POST normale Bestellung                │ 200 + Order    │ 200 + Order    │
 * │ C03 │ POST Menge = 0                         │ 400            │ 400            │
 * │ C04 │ POST Menge negativ (-5)                │ 400            │ 400            │
 * │ C05 │ POST Einzelpreis = 0.00                │ 400            │ 400            │
 * │ C06 │ POST Einzelpreis negativ (-9.99)       │ 400            │ 400            │
 * │ C07 │ POST Produktname leer ("")             │ 400            │ 400            │
 * │ C08 │ POST Produktname fehlt (null)          │ 400            │ 400            │
 * │ C09 │ POST Sehr grosse Zahlen (9999999.99×99)│ 200 + Order    │ 200 + Order    │
 * │ C10 │ POST Falsche Eingabe (String als Preis)│ 400            │ 400            │
 * │ C11 │ DELETE /api/orders/1                   │ 204            │ 204            │
 * │ C12 │ GET /api/orders/summe                  │ 200 + Summe    │ 200 + Summe    │
 * └─────┴────────────────────────────────────────┴────────────────┴────────────────┘
 */
@WebMvcTest(OrderController.class)
@DisplayName("OrderController – Integrationstests mit MockMvc")
class OrderControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private OrderService orderService;

    // Hilfsmethode: gueltigen Order als JSON-String erstellen
    private String orderJson(String produktname, Object einzelpreis, Object menge) throws Exception {
        return String.format(
            "{\"produktname\":\"%s\",\"einzelpreis\":%s,\"menge\":%s}",
            produktname, einzelpreis, menge
        );
    }

    // Hilfsmethode: gespeicherten Order simulieren
    private Order gespeicherterOrder(String name, double preis, int menge) {
        Order o = new Order();
        o.setProduktname(name);
        o.setEinzelpreis(preis);
        o.setMenge(menge);
        return o;
    }

    // ─── GET /api/orders ──────────────────────────────────────────────────────

    @Test
    @WithMockUser
    @DisplayName("TC-C01: GET /api/orders – gibt leere Liste zurueck")
    void getAllOrders_leereListe() throws Exception {
        when(orderService.alleBestellungen()).thenReturn(List.of());

        mockMvc.perform(get("/api/orders"))
            .andExpect(status().isOk())
            .andExpect(content().json("[]"));
    }

    // ─── POST /api/orders – Gueltige Eingaben ────────────────────────────────

    @Test
    @WithMockUser
    @DisplayName("TC-C02: POST normale Bestellung – 200 OK")
    void createOrder_normaleWerte() throws Exception {
        Order saved = gespeicherterOrder("Laptop", 999.99, 2);
        when(orderService.bestellungHinzufuegen(any())).thenReturn(saved);

        mockMvc.perform(post("/api/orders").with(csrf())
                .contentType(MediaType.APPLICATION_JSON)
                .content(orderJson("Laptop", 999.99, 2)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.produktname").value("Laptop"))
            .andExpect(jsonPath("$.einzelpreis").value(999.99))
            .andExpect(jsonPath("$.menge").value(2));
    }

    @Test
    @WithMockUser
    @DisplayName("TC-C09: POST sehr grosse Zahlen – 200 OK (Grenzwert)")
    void createOrder_sehrGrosseZahlen() throws Exception {
        Order saved = gespeicherterOrder("Maschine", 9_999_999.99, 99);
        when(orderService.bestellungHinzufuegen(any())).thenReturn(saved);

        mockMvc.perform(post("/api/orders").with(csrf())
                .contentType(MediaType.APPLICATION_JSON)
                .content(orderJson("Maschine", 9999999.99, 99)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.einzelpreis").value(9_999_999.99));
    }

    // ─── POST /api/orders – Ungueltige Eingaben → HTTP 400 ───────────────────

    @Test
    @WithMockUser
    @DisplayName("TC-C03: POST Menge = 0 – 400 Bad Request")
    void createOrder_mengeNull_400() throws Exception {
        mockMvc.perform(post("/api/orders").with(csrf())
                .contentType(MediaType.APPLICATION_JSON)
                .content(orderJson("Stift", 1.50, 0)))
            .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser
    @DisplayName("TC-C04: POST Menge negativ (-5) – 400 Bad Request")
    void createOrder_mengeNegativ_400() throws Exception {
        mockMvc.perform(post("/api/orders").with(csrf())
                .contentType(MediaType.APPLICATION_JSON)
                .content(orderJson("Stift", 1.50, -5)))
            .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser
    @DisplayName("TC-C05: POST Einzelpreis = 0.00 – 400 Bad Request")
    void createOrder_preisNull_400() throws Exception {
        mockMvc.perform(post("/api/orders").with(csrf())
                .contentType(MediaType.APPLICATION_JSON)
                .content(orderJson("Stift", 0.00, 1)))
            .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser
    @DisplayName("TC-C06: POST Einzelpreis negativ (-9.99) – 400 Bad Request")
    void createOrder_preisNegativ_400() throws Exception {
        mockMvc.perform(post("/api/orders").with(csrf())
                .contentType(MediaType.APPLICATION_JSON)
                .content(orderJson("Stift", -9.99, 1)))
            .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser
    @DisplayName("TC-C07: POST Produktname leer (\"\") – 400 Bad Request")
    void createOrder_produktnameLeer_400() throws Exception {
        mockMvc.perform(post("/api/orders").with(csrf())
                .contentType(MediaType.APPLICATION_JSON)
                .content(orderJson("", 5.00, 1)))
            .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser
    @DisplayName("TC-C08: POST Produktname fehlt (null) – 400 Bad Request")
    void createOrder_produktnameNull_400() throws Exception {
        String json = "{\"einzelpreis\":5.00,\"menge\":1}";
        mockMvc.perform(post("/api/orders").with(csrf())
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
            .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser
    @DisplayName("TC-C10: POST falscher Datentyp (String als Preis) – 400 Bad Request")
    void createOrder_falscherDatentyp_400() throws Exception {
        String json = "{\"produktname\":\"Test\",\"einzelpreis\":\"abc\",\"menge\":1}";
        mockMvc.perform(post("/api/orders").with(csrf())
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
            .andExpect(status().isBadRequest());
    }

    // ─── DELETE /api/orders/{id} ──────────────────────────────────────────────

    @Test
    @WithMockUser
    @DisplayName("TC-C11: DELETE /api/orders/1 – 204 No Content")
    void deleteOrder_204() throws Exception {
        doNothing().when(orderService).bestellungLoeschen(1L);

        mockMvc.perform(delete("/api/orders/1").with(csrf()))
            .andExpect(status().isNoContent());

        verify(orderService, times(1)).bestellungLoeschen(1L);
    }

    // ─── GET /api/orders/summe ────────────────────────────────────────────────

    @Test
    @WithMockUser
    @DisplayName("TC-C12: GET /api/orders/summe – gibt Gesamtsumme zurueck")
    void getSumme_200() throws Exception {
        when(orderService.gesamtsumme()).thenReturn(149.97);

        mockMvc.perform(get("/api/orders/summe"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.gesamtsumme").value(149.97));
    }
}
