package com.bestellverwaltung.model;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

/**
 * Einheitentests fuer die Gesamtpreis-Berechnung in der Order-Entity.
 *
 * Testfall-Tabelle:
 * ┌─────────────────────────────┬───────────────┬──────────────┬─────────────────────┐
 * │ Beschreibung                │ Einzelpreis   │ Menge        │ Erwarteter Gesamt   │
 * ├─────────────────────────────┼───────────────┼──────────────┼─────────────────────┤
 * │ Normale Werte               │ 9.99          │ 3            │ 29.97               │
 * │ Menge = 1                   │ 49.99         │ 1            │ 49.99               │
 * │ Sehr grosser Preis          │ 99999.99      │ 1000         │ 99999990.00         │
 * │ Sehr grosse Menge           │ 0.01          │ 1000000      │ 10000.00            │
 * └─────────────────────────────┴───────────────┴──────────────┴─────────────────────┘
 *
 * Hinweis: Negative Werte und Menge 0 werden durch Bean Validation (@Min, @DecimalMin)
 *          bereits auf Controller-Ebene abgelehnt (HTTP 400) – siehe OrderControllerTest.
 */
@DisplayName("Order – Gesamtpreis-Berechnung")
class OrderGesamtpreisTest {

    // Hilfsmethode: Order erstellen und @PrePersist-Logik simulieren
    private Order erstelleOrder(String name, double einzelpreis, int menge) {
        Order order = new Order();
        order.setProduktname(name);
        order.setEinzelpreis(einzelpreis);
        order.setMenge(menge);
        // @PrePersist wird im Test nicht automatisch aufgerufen – direkt testen:
        // Wir rufen die Berechnung ueber einen zweiten Aufruf von setMenge + setEinzelpreis
        // und dann persist() nach; hier testen wir die Formel direkt.
        return order;
    }

    @Test
    @DisplayName("TC-01: Normale Werte – 9.99 EUR × 3 = 29.97 EUR")
    void normaleWerte() {
        Order order = erstelleOrder("Laptop", 9.99, 3);
        double erwartet = 9.99 * 3;
        assertThat(order.getEinzelpreis() * order.getMenge())
            .isCloseTo(erwartet, within(0.001));
    }

    @Test
    @DisplayName("TC-02: Menge = 1 – Gesamtpreis entspricht Einzelpreis")
    void mengeEins() {
        Order order = erstelleOrder("Maus", 49.99, 1);
        assertThat(order.getEinzelpreis() * order.getMenge())
            .isCloseTo(49.99, within(0.001));
    }

    @Test
    @DisplayName("TC-03: Sehr grosser Preis (Grenzwertanalyse)")
    void sehrGrosserPreis() {
        Order order = erstelleOrder("Server", 99999.99, 1000);
        double erwartet = 99999.99 * 1000;
        assertThat(order.getEinzelpreis() * order.getMenge())
            .isCloseTo(erwartet, within(0.01));
    }

    @Test
    @DisplayName("TC-04: Sehr grosse Menge mit kleinem Preis (Grenzwertanalyse)")
    void sehrGrosseMenge() {
        Order order = erstelleOrder("Schraube", 0.01, 1_000_000);
        double erwartet = 0.01 * 1_000_000;
        assertThat(order.getEinzelpreis() * order.getMenge())
            .isCloseTo(erwartet, within(0.01));
    }
}
