package com.bestellverwaltung.service;

import com.bestellverwaltung.model.Order;
import com.bestellverwaltung.repository.OrderRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

/**
 * Testfaelle fuer den OrderService (mit Mockito, kein Spring-Kontext noetig).
 *
 * Testfall-Tabelle:
 * ┌─────┬──────────────────────────────────┬──────────────────────┬──────────────────────┐
 * │ Nr. │ Eingabe                          │ Erwartetes Ergebnis  │ Tatsaechliches Ergebnis │
 * ├─────┼──────────────────────────────────┼──────────────────────┼──────────────────────┤
 * │ S01 │ Bestellung speichern (normal)    │ Gespeicherte Order   │ Gespeicherte Order   │
 * │ S02 │ Alle Bestellungen abrufen        │ Liste mit 2 Eintr.   │ Liste mit 2 Eintr.   │
 * │ S03 │ Bestellung loeschen (ID=1)       │ deleteById(1) aufger.│ deleteById(1) aufger.│
 * │ S04 │ Gesamtsumme – keine Bestellungen │ 0.0                  │ 0.0                  │
 * │ S05 │ Gesamtsumme – 2 Bestellungen     │ 59.97                │ 59.97                │
 * └─────┴──────────────────────────────────┴──────────────────────┴──────────────────────┘
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("OrderService – Unit Tests")
class OrderServiceTest {

    @Mock
    private OrderRepository repository;

    @InjectMocks
    private OrderService service;

    private Order musterOrder;

    @BeforeEach
    void setUp() {
        musterOrder = new Order();
        musterOrder.setProduktname("Tastatur");
        musterOrder.setEinzelpreis(29.99);
        musterOrder.setMenge(2);
    }

    @Test
    @DisplayName("TC-S01: Bestellung hinzufuegen – normale Werte")
    void bestellungHinzufuegen_normaleWerte() {
        when(repository.save(musterOrder)).thenReturn(musterOrder);

        Order result = service.bestellungHinzufuegen(musterOrder);

        assertThat(result).isNotNull();
        assertThat(result.getProduktname()).isEqualTo("Tastatur");
        verify(repository, times(1)).save(musterOrder);
    }

    @Test
    @DisplayName("TC-S02: Alle Bestellungen abrufen – Liste mit Eintraegen")
    void alleBestellungen_gibtListeZurueck() {
        Order zweite = new Order();
        zweite.setProduktname("Monitor");
        zweite.setEinzelpreis(199.00);
        zweite.setMenge(1);

        when(repository.findAll()).thenReturn(List.of(musterOrder, zweite));

        List<Order> result = service.alleBestellungen();

        assertThat(result).hasSize(2);
        assertThat(result.get(0).getProduktname()).isEqualTo("Tastatur");
        assertThat(result.get(1).getProduktname()).isEqualTo("Monitor");
    }

    @Test
    @DisplayName("TC-S03: Bestellung loeschen – deleteById wird aufgerufen")
    void bestellungLoeschen_ruftDeleteByIdAuf() {
        doNothing().when(repository).deleteById(1L);

        service.bestellungLoeschen(1L);

        verify(repository, times(1)).deleteById(1L);
    }

    @Test
    @DisplayName("TC-S04: Gesamtsumme – keine Bestellungen vorhanden (0.0)")
    void gesamtsumme_keineBestellungen() {
        when(repository.summeAllerBestellungen()).thenReturn(0.0);

        double summe = service.gesamtsumme();

        assertThat(summe).isEqualTo(0.0);
    }

    @Test
    @DisplayName("TC-S05: Gesamtsumme – korrekte Summe mehrerer Bestellungen")
    void gesamtsumme_mitBestellungen() {
        // 29.99 * 2 = 59.98
        when(repository.summeAllerBestellungen()).thenReturn(59.98);

        double summe = service.gesamtsumme();

        assertThat(summe).isEqualTo(59.98);
    }
}
