import { useState, useEffect } from 'react'
import axios from 'axios'
import OrderList from './components/OrderList'
import OrderForm from './components/OrderForm'

const API = 'http://localhost:8081/api/orders'

const styles = {
  root: {
    minHeight: '100vh',
    display: 'flex',
    flexDirection: 'column',
  },
  inner: {
    maxWidth: 1000,
    width: '100%',
    margin: '0 auto',
    padding: '0 1.25rem',
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: '0.75rem',
    padding: '1.5rem 0 2rem',
    borderBottom: '1px solid var(--border)',
  },
  logo: {
    fontFamily: 'var(--font-display)',
    fontSize: '1.1rem',
    fontWeight: 800,
    letterSpacing: '0.08em',
    textTransform: 'uppercase',
    color: 'var(--text-primary)',
  },
  logoDot: {
    display: 'inline-block',
    width: 7,
    height: 7,
    borderRadius: '50%',
    background: 'var(--accent)',
    marginLeft: 6,
    verticalAlign: 'middle',
    position: 'relative',
    top: -1,
  },
  headerRight: {
    display: 'flex',
    alignItems: 'center',
    gap: '1.5rem',
  },
  username: {
    color: 'var(--text-secondary)',
    fontSize: '0.75rem',
    letterSpacing: '0.05em',
  },
  usernameValue: {
    color: 'var(--accent)',
    fontWeight: 500,
  },
  logoutBtn: {
    background: 'none',
    border: '1px solid var(--border)',
    color: 'var(--text-secondary)',
    padding: '0.35rem 0.85rem',
    fontFamily: 'var(--font-mono)',
    fontSize: '0.7rem',
    letterSpacing: '0.08em',
    textTransform: 'uppercase',
    cursor: 'pointer',
    transition: 'all 0.15s',
  },
  main: {
    flex: 1,
    paddingTop: '2.5rem',
    paddingBottom: '2.5rem',
  },
  footer: {
    borderTop: '1px solid var(--border)',
    padding: '1.75rem 0',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'baseline',
  },
  footerLabel: {
    fontFamily: 'var(--font-display)',
    fontSize: '0.7rem',
    fontWeight: 600,
    letterSpacing: '0.12em',
    textTransform: 'uppercase',
    color: 'var(--text-secondary)',
  },
  footerAmount: {
    fontFamily: 'var(--font-display)',
    fontSize: '2rem',
    fontWeight: 800,
    color: 'var(--accent)',
    letterSpacing: '-0.02em',
  },
  footerCurrency: {
    fontSize: '1rem',
    fontWeight: 400,
    marginLeft: '0.25rem',
    color: 'var(--text-secondary)',
  },
}

function App({ keycloak }) {
  const [orders, setOrders] = useState([])
  const [summe, setSumme] = useState(0)

  useEffect(() => {
    const interceptor = axios.interceptors.request.use(async (config) => {
      await keycloak.updateToken(30).catch(() => keycloak.login())
      config.headers.Authorization = `Bearer ${keycloak.token}`
      return config
    })
    return () => axios.interceptors.request.eject(interceptor)
  }, [keycloak])

  const laden = async () => {
    const [ordersRes, summeRes] = await Promise.all([
      axios.get(API),
      axios.get(`${API}/summe`),
    ])
    setOrders(ordersRes.data)
    setSumme(summeRes.data.gesamtsumme)
  }

  useEffect(() => { laden() }, [])

  const hinzufuegen = async (order) => {
    await axios.post(API, order)
    await laden()
  }

  const aktualisieren = async (id, data) => {
    await axios.put(`${API}/${id}`, data)
    await laden()
  }

  const loeschen = async (id) => {
    await axios.delete(`${API}/${id}`)
    await laden()
  }

  const handleLogoutHover = (e, enter) => {
    e.target.style.borderColor = enter ? 'var(--text-secondary)' : 'var(--border)'
    e.target.style.color = enter ? 'var(--text-primary)' : 'var(--text-secondary)'
  }

  const [whole, decimal] = summe.toFixed(2).split('.')

  return (
    <div style={styles.root}>
      <div style={styles.inner}>

        <header style={styles.header}>
          <div style={styles.logo}>
            Bestellverwaltung
            <span style={styles.logoDot} />
          </div>
          <div style={styles.headerRight}>
            <span style={styles.username}>
              /{' '}
              <span style={styles.usernameValue}>
                {keycloak.tokenParsed?.preferred_username}
              </span>
            </span>
            <button
              style={styles.logoutBtn}
              onClick={() => keycloak.logout()}
              onMouseEnter={(e) => handleLogoutHover(e, true)}
              onMouseLeave={(e) => handleLogoutHover(e, false)}
            >
              Abmelden
            </button>
          </div>
        </header>

        <main style={styles.main}>
          <OrderForm onSubmit={hinzufuegen} />
          <OrderList orders={orders} onDelete={loeschen} onUpdate={aktualisieren} />
        </main>

        <footer style={styles.footer}>
          <span style={styles.footerLabel}>Gesamtsumme</span>
          <span style={styles.footerAmount}>
            {whole}
            <span style={{ fontSize: '1.25rem', color: 'var(--text-secondary)' }}>.{decimal}</span>
            <span style={styles.footerCurrency}>€</span>
          </span>
        </footer>

      </div>
    </div>
  )
}

export default App
