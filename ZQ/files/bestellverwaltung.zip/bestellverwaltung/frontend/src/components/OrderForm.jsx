import { useState } from 'react'

const s = {
  section: {
    marginBottom: '3rem',
  },
  sectionLabel: {
    fontFamily: 'var(--font-display)',
    fontSize: '0.65rem',
    fontWeight: 700,
    letterSpacing: '0.15em',
    textTransform: 'uppercase',
    color: 'var(--text-secondary)',
    marginBottom: '1.25rem',
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
  },
  sectionLine: {
    flex: 1,
    height: 1,
    background: 'var(--border)',
  },
  form: {
    display: 'grid',
    gridTemplateColumns: '1fr auto auto auto',
    gap: '0',
    border: '1px solid var(--border)',
  },
  fieldWrap: {
    position: 'relative',
    borderRight: '1px solid var(--border)',
  },
  label: {
    position: 'absolute',
    top: '0.6rem',
    left: '1rem',
    fontSize: '0.6rem',
    letterSpacing: '0.12em',
    textTransform: 'uppercase',
    color: 'var(--text-muted)',
    fontFamily: 'var(--font-display)',
    fontWeight: 600,
    pointerEvents: 'none',
    transition: 'color 0.15s',
  },
  input: {
    width: '100%',
    background: 'transparent',
    border: 'none',
    outline: 'none',
    color: 'var(--text-primary)',
    fontFamily: 'var(--font-mono)',
    fontSize: '0.875rem',
    padding: '1.75rem 1rem 0.6rem',
    transition: 'background 0.15s',
    WebkitAppearance: 'none',
    MozAppearance: 'textfield',
  },
  submitBtn: {
    background: 'var(--accent)',
    border: 'none',
    color: '#000',
    fontFamily: 'var(--font-display)',
    fontSize: '0.7rem',
    fontWeight: 800,
    letterSpacing: '0.12em',
    textTransform: 'uppercase',
    padding: '0 2rem',
    cursor: 'pointer',
    transition: 'background 0.15s',
    whiteSpace: 'nowrap',
  },
  error: {
    marginTop: '0.75rem',
    fontSize: '0.7rem',
    color: 'var(--danger)',
    letterSpacing: '0.04em',
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem',
  },
}

export default function OrderForm({ onSubmit }) {
  const [form, setForm] = useState({ produktname: '', einzelpreis: '', menge: '' })
  const [fehler, setFehler] = useState('')
  const [loading, setLoading] = useState(false)
  const [focused, setFocused] = useState(null)

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setFehler('')

    const einzelpreis = parseFloat(form.einzelpreis)
    const menge = parseInt(form.menge)

    if (!form.produktname || isNaN(einzelpreis) || einzelpreis <= 0 || isNaN(menge) || menge < 1) {
      setFehler('Alle Felder korrekt ausfüllen.')
      return
    }

    setLoading(true)
    try {
      await onSubmit({ produktname: form.produktname, einzelpreis, menge })
      setForm({ produktname: '', einzelpreis: '', menge: '' })
    } catch {
      setFehler('Fehler beim Speichern.')
    } finally {
      setLoading(false)
    }
  }

  const fieldStyle = (name) => ({
    ...s.fieldWrap,
    background: focused === name ? 'var(--surface-hover)' : 'transparent',
  })

  const labelStyle = (name) => ({
    ...s.label,
    color: focused === name ? 'var(--accent)' : 'var(--text-muted)',
  })

  return (
    <div style={s.section}>
      <div style={s.sectionLabel}>
        Neue Bestellung
        <span style={s.sectionLine} />
      </div>

      <form onSubmit={handleSubmit}>
        <div style={s.form} className="order-form-grid">
          {/* Produktname */}
          <div style={fieldStyle('produktname')}>
            <span style={labelStyle('produktname')}>Produkt</span>
            <input
              name="produktname"
              value={form.produktname}
              onChange={handleChange}
              onFocus={() => setFocused('produktname')}
              onBlur={() => setFocused(null)}
              style={s.input}
              autoComplete="off"
            />
          </div>

          {/* Einzelpreis */}
          <div style={{ ...fieldStyle('einzelpreis'), minWidth: 160 }}>
            <span style={labelStyle('einzelpreis')}>Einzelpreis €</span>
            <input
              name="einzelpreis"
              type="number"
              step="0.01"
              min="0.01"
              value={form.einzelpreis}
              onChange={handleChange}
              onFocus={() => setFocused('einzelpreis')}
              onBlur={() => setFocused(null)}
              style={s.input}
            />
          </div>

          {/* Menge */}
          <div style={{ ...fieldStyle('menge'), minWidth: 110, borderRight: 'none' }}>
            <span style={labelStyle('menge')}>Menge</span>
            <input
              name="menge"
              type="number"
              min="1"
              value={form.menge}
              onChange={handleChange}
              onFocus={() => setFocused('menge')}
              onBlur={() => setFocused(null)}
              style={s.input}
            />
          </div>

          {/* Submit */}
          <button
            type="submit"
            style={{
              ...s.submitBtn,
              opacity: loading ? 0.6 : 1,
            }}
            disabled={loading}
            onMouseEnter={(e) => { if (!loading) e.target.style.background = '#d4ff1a' }}
            onMouseLeave={(e) => { e.target.style.background = 'var(--accent)' }}
          >
            {loading ? '...' : '+ Hinzufügen'}
          </button>
        </div>

        {fehler && (
          <div style={s.error}>
            <span>—</span> {fehler}
          </div>
        )}
      </form>
    </div>
  )
}
