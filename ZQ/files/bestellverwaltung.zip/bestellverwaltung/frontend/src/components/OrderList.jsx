import { useState, useRef, useEffect } from 'react'

const s = {
  sectionLabel: {
    fontFamily: 'var(--font-display)',
    fontSize: '0.65rem',
    fontWeight: 700,
    letterSpacing: '0.15em',
    textTransform: 'uppercase',
    color: 'var(--text-secondary)',
    marginBottom: '1.25rem',
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
  },
  count: {
    fontFamily: 'var(--font-mono)',
    fontSize: '0.6rem',
    color: 'var(--text-muted)',
    fontWeight: 400,
    letterSpacing: '0.05em',
  },
  sectionLine: {
    flex: 1,
    height: 1,
    background: 'var(--border)',
  },
  empty: {
    padding: '3rem 0',
    textAlign: 'center',
    color: 'var(--text-muted)',
    fontSize: '0.75rem',
    letterSpacing: '0.08em',
    fontFamily: 'var(--font-display)',
    textTransform: 'uppercase',
    borderTop: '1px solid var(--border)',
    borderBottom: '1px solid var(--border)',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    borderTop: '1px solid var(--border)',
  },
  theadTr: {
    borderBottom: '1px solid var(--border)',
  },
  th: {
    fontFamily: 'var(--font-display)',
    fontSize: '0.6rem',
    fontWeight: 700,
    letterSpacing: '0.12em',
    textTransform: 'uppercase',
    color: 'var(--text-muted)',
    padding: '0.75rem 1rem',
    textAlign: 'left',
  },
  thRight: {
    fontFamily: 'var(--font-display)',
    fontSize: '0.6rem',
    fontWeight: 700,
    letterSpacing: '0.12em',
    textTransform: 'uppercase',
    color: 'var(--text-muted)',
    padding: '0.75rem 1rem',
    textAlign: 'right',
  },
}

const tdBase = { padding: '0 1rem', height: 52, verticalAlign: 'middle' }

// Gemeinsames Inline-Edit-Input-Styling
const inlineInputStyle = (align = 'left', width = '100%') => ({
  background: 'var(--surface-hover)',
  border: '1px solid var(--accent)',
  outline: 'none',
  color: 'var(--text-primary)',
  fontFamily: align === 'right' ? 'var(--font-mono)' : 'var(--font-display)',
  fontWeight: align === 'right' ? 400 : 600,
  fontSize: '0.875rem',
  padding: '0.25rem 0.4rem',
  width,
  textAlign: align,
  caretColor: 'var(--accent)',
})

function EditableCell({ value, type = 'text', align = 'left', displayStyle = {}, onSave }) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(String(value))
  const inputRef = useRef(null)

  useEffect(() => {
    if (editing) {
      inputRef.current?.focus()
      inputRef.current?.select()
    }
  }, [editing])

  const commit = () => {
    const parsed = type === 'number'
      ? parseFloat(draft)
      : type === 'integer'
      ? parseInt(draft)
      : draft.trim()

    const invalid =
      (type === 'number' && (isNaN(parsed) || parsed <= 0)) ||
      (type === 'integer' && (isNaN(parsed) || parsed < 1)) ||
      (type === 'text' && !parsed)

    if (invalid) {
      setDraft(String(value)) // revert
    } else {
      onSave(parsed)
    }
    setEditing(false)
  }

  const onKeyDown = (e) => {
    if (e.key === 'Enter') commit()
    if (e.key === 'Escape') { setDraft(String(value)); setEditing(false) }
  }

  if (editing) {
    return (
      <td style={{ ...tdBase, textAlign: align }}>
        <input
          ref={inputRef}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onBlur={commit}
          onKeyDown={onKeyDown}
          type={type === 'text' ? 'text' : 'number'}
          step={type === 'number' ? '0.01' : '1'}
          style={inlineInputStyle(align, type === 'integer' ? '5rem' : type === 'number' ? '8rem' : '100%')}
        />
      </td>
    )
  }

  return (
    <td
      onDoubleClick={() => { setDraft(String(value)); setEditing(true) }}
      style={{
        ...tdBase,
        textAlign: align,
        cursor: 'text',
        userSelect: 'none',
        ...displayStyle,
      }}
      title="Doppelklick zum Bearbeiten"
    >
      {/* Subtle underline hint on the editable cells */}
      <span style={{ borderBottom: '1px dashed var(--text-muted)', paddingBottom: 1 }}>
        {typeof value === 'number' ? value.toFixed(type === 'integer' ? 0 : 2) : value}
        {type === 'number' ? ' €' : ''}
        {type === 'integer' ? '' : ''}
      </span>
    </td>
  )
}

function OrderRow({ order, onDelete, onUpdate }) {
  const [hovered, setHovered] = useState(false)
  const [deleting, setDeleting] = useState(false)

  const save = (field) => async (val) => {
    await onUpdate(order.id, {
      produktname: field === 'produktname' ? val : order.produktname,
      einzelpreis: field === 'einzelpreis' ? val : order.einzelpreis,
      menge:       field === 'menge'       ? val : order.menge,
    })
  }

  const handleDelete = async () => {
    setDeleting(true)
    await onDelete(order.id)
  }

  return (
    <tr
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        borderBottom: '1px solid var(--border)',
        background: hovered ? 'var(--surface-hover)' : 'transparent',
        transition: 'background 0.1s',
        opacity: deleting ? 0.4 : 1,
      }}
    >
      {/* ID – nicht editierbar */}
      <td style={{ ...tdBase, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: '0.7rem' }}>
        #{String(order.id).padStart(3, '0')}
      </td>

      {/* Produktname – editierbar */}
      <EditableCell
        value={order.produktname}
        type="text"
        align="left"
        displayStyle={{ color: 'var(--text-primary)', fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: '0.875rem' }}
        onSave={save('produktname')}
      />

      {/* Einzelpreis – editierbar */}
      <EditableCell
        value={order.einzelpreis}
        type="number"
        align="right"
        displayStyle={{ color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)' }}
        onSave={save('einzelpreis')}
      />

      {/* Menge – editierbar */}
      <EditableCell
        value={order.menge}
        type="integer"
        align="right"
        displayStyle={{ color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)' }}
        onSave={(val) => save('menge')(val)}
      />

      {/* Gesamtpreis – berechnet, nicht editierbar */}
      <td style={{ ...tdBase, fontFamily: 'var(--font-mono)', fontWeight: 500, textAlign: 'right', color: 'var(--text-primary)', fontSize: '0.9rem' }}>
        {order.gesamtpreis.toFixed(2)} €
      </td>

      {/* Delete */}
      <td style={{ ...tdBase, textAlign: 'right', width: 80 }}>
        <button
          onClick={handleDelete}
          disabled={deleting}
          style={{
            background: 'none',
            border: 'none',
            color: hovered ? 'var(--danger)' : 'var(--text-muted)',
            fontFamily: 'var(--font-mono)',
            fontSize: '0.75rem',
            cursor: 'pointer',
            padding: '0.25rem 0.5rem',
            transition: 'color 0.15s',
            letterSpacing: '0.04em',
          }}
        >
          {deleting ? '...' : 'del'}
        </button>
      </td>
    </tr>
  )
}

export default function OrderList({ orders, onDelete, onUpdate }) {
  return (
    <div>
      <div style={s.sectionLabel}>
        Bestellungen
        <span style={s.count}>({orders.length})</span>
        <span style={s.sectionLine} />
      </div>

      {orders.length === 0 ? (
        <div style={s.empty}>Keine Bestellungen vorhanden</div>
      ) : (
        <div className="table-scroll">
          <table style={s.table}>
            <thead>
              <tr style={s.theadTr}>
                <th style={s.th}>Nr.</th>
                <th style={s.th}>Produkt</th>
                <th style={s.thRight}>Einzelpreis</th>
                <th style={s.thRight}>Menge</th>
                <th style={s.thRight}>Gesamt</th>
                <th style={{ ...s.thRight, width: 80 }} />
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <OrderRow key={o.id} order={o} onDelete={onDelete} onUpdate={onUpdate} />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
