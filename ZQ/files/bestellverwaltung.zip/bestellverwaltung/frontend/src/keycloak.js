import Keycloak from 'keycloak-js'

const keycloak = new Keycloak({
  url: 'http://localhost:8080',
  realm: 'bestellverwaltung',
  clientId: 'bestellverwaltung-app',
})

export default keycloak
