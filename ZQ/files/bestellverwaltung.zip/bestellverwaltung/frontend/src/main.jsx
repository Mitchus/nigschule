import './index.css'
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import keycloak from './keycloak'

// Keycloak initialisieren bevor React gerendert wird
keycloak.init({ onLoad: 'login-required' }).then((authenticated) => {
  if (!authenticated) {
    window.location.reload()
    return
  }

  ReactDOM.createRoot(document.getElementById('root')).render(
    <React.StrictMode>
      <App keycloak={keycloak} />
    </React.StrictMode>
  )
})
